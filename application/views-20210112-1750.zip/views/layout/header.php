<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="<?= base_url(); ?>assets/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?= base_url(); ?>/assets/fontawesome/css/all.css">
    <link rel="stylesheet" href="<?= base_url(); ?>/assets/css/main.css">
    <link rel="stylesheet" href="<?= base_url(); ?>/assets/jquery-ui/jquery-ui.css">
    <link rel="stylesheet" href="<?= base_url(); ?>/assets/daterangepicker/daterangepicker.css">
    <link rel="stylesheet" href="<?= base_url(); ?>/assets/jquery-ui/jquery-ui.css">
    <link rel="stylesheet" href="<?= base_url(); ?>/assets/datepicker/css/datepicker.css" />
    <link rel="stylesheet" href="<?= base_url(); ?>/assets/select2/dist/css/select2.min.css" />
    <script src="<?= base_url(); ?>/assets/jquery/dist/jquery.min.js"></script>


    <title><?= $title; ?></title>
    <style>
    </style>
</head>

<body>
    <nav class="navbar navbar-expand-md fixed-top navbar-light bg-light ">
        <div class="container-fluid">
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ms-auto justify-content-end bg-light justify-content-end" style="font-size: 1em;">
                    <?php if ($_SESSION['role'] < 3) { ?>
                        <li class="nav-item">
                            <a class="nav-link active text-dark" aria-current="page" href="<?= base_url('dashboard'); ?>">Search</a>
                        </li>
                    <?php } ?>
                    <?php if ($_SESSION['role'] != 2) { ?>
                        <li class="nav-item">
                            <a class="nav-link text-dark" href="<?= base_url('visitor'); ?>">Visitor</a>
                        </li>
                        <?php if ($_SESSION['role'] < 3) { ?>
                            <?php if ($_SESSION['role'] == 0) { ?>
                                <li class="nav-item">
                                    <a class="nav-link text-dark" href="<?= base_url('alasan'); ?>" id="navAlasan">Alasan</a>
                                </li>
                            <?php } ?>
                            <li class="nav-item">
                                <a class="nav-link text-dark" href="<?= base_url('closing'); ?>">Closing</a>
                            </li>
                            <!-- <div class="notif">
                                <li class="nav-item">
                                    <a class="nav-link text-danger notifBell" href="<?= base_url('closing'); ?>"><i class="far fa-bell"></i></a>
                                </li>
                            </div> -->
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                    <?= $_SESSION['perusahaan']; ?>
                                </a>
                                <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                    <?php if ($_SESSION['role'] <= 2) { ?>
                                        <li><a class="dropdown-item" href="<?= base_url('auth/user'); ?>">User</a></li>
                                    <?php } ?>
                                    <li><a class="dropdown-item" href="<?= base_url('user/resetPassword'); ?>">Reset Password</a></li>
                                </ul>
                            </li>
                        <?php } ?>
                    <?php } ?>
                    <li class="nav-item">
                        <a class="nav-link text-danger" href="<?= base_url('auth/logout'); ?>" id="logout" title="Logout"><i class="fas fa-power-off"></i></a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

</body>