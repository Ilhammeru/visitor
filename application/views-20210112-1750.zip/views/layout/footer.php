<div class="modal modalPassword1 fade" id="exampleModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Password</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close" id="close"></button>
            </div>
            <div class="modal-body">
                <div class="hapusBaris">
                    <div class="row">
                        <input type="password" class="form-control" id="password1" placeholder="Masukan password anda">
                    </div>
                </div>
                <div id="targetForm"></div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary simpanAlasan" onclick="masukAlasan()">Lanjut</button>
            </div>
        </div>
    </div>
</div>

<!-- Optional JavaScript; choose one of the two! -->


<script>
    $(document).ready(function() {
        ambilNotif();
    })
    $('#logout').click(function(e) {
        e.preventDefault();
        swal("Anda yakin ingin Logout", {
                buttons: {
                    cancel: 'Tidak',
                    catch: {
                        text: "Logout",
                        value: "logout"
                    },
                }
            })
            .then((value) => {
                switch (value) {
                    case "logout":
                        $.ajax({
                            type: 'POST',
                            url: '<?= base_url('auth/logout'); ?>',
                            dataType: 'text',
                            success: function(data) {
                                swal('Berhasil', 'Sampai jumpa kembali!', 'success');
                                setTimeout(function() {
                                    var url = '<?= base_url('auth'); ?>';
                                    window.location = url;
                                }, 800);
                            }
                        })
                        break;
                    default:
                        swal("Silahkan dilanjutkan", {
                            timer: 300,
                        })
                }
            })
    })

    $('#navAlasan').click(function(e) {
        e.preventDefault();
        $('.modalPassword1').modal('show');
    })

    function masukAlasan() {
        var pass = $('#password1').val();
        var nama = '<?= $_SESSION['user']; ?>';
        $.ajax({
            type: 'POST',
            data: 'pass=' + pass + '&nama=' + nama,
            url: '<?= base_url('auth/cekPassAlasan'); ?>',
            dataType: 'text',
            success: function(hasil) {
                if (hasil == 'oke') {
                    var url = '<?= base_url('alasan'); ?>';
                    window.location = url;
                } else {
                    swal('Error', 'Password salah', 'warning', {
                        buttons: false,
                        timer: 900
                    })
                    $('#password1').val('');
                }
            }
        })
    }

    function ambilNotif() {
        $.ajax({
            type: 'POST',
            url: '<?= base_url('closing/ambilDataClosing'); ?>',
            dataType: 'text',
            success: function(hasil) {
                if (hasil > 0) {
                    $('.notifBell').attr('style', 'color: red;')
                }
            }
        })
    }
</script>
<!-- Option 1: Bootstrap Bundle with Popper -->
<script src="<?= base_url(); ?>assets/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="<?= base_url(); ?>assets/sweetalert/dist/sweetalert.min.js"></script>
<script src="<?= base_url(); ?>assets/jquery/dist/jquery.min.js"></script>
<script src="<?= base_url(); ?>assets/jquery-ui/jquery-ui.js"></script>
<script src="<?= base_url(); ?>/assets/datepicker/js/bootstrap-datepicker.js"></script>
<script src="<?= base_url(); ?>/assets/daterangepicker/moment.min.js"></script>
<script src="<?= base_url(); ?>/assets/daterangepicker/daterangepicker.js"></script>
<script src="<?= base_url(); ?>/assets/select2/dist/js/select2.min.js"></script>


<!-- Option 2: Separate Popper and Bootstrap JS -->
<!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js" integrity="sha384-q2kxQ16AaE6UbzuKqyBE9/u/KzioAlnx2maXQHiDX9d4/zp8Ok3f+M7DPm+Ib6IU" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.min.js" integrity="sha384-pQQkAEnwaBkjpqZ8RU1fF1AKtTcHJwFl3pblpTlHXybJjHpMYo79HY3hIi4NKxyj" crossorigin="anonymous"></script>
    -->
</body>

</html>