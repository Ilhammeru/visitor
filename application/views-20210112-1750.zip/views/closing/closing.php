<?php if ($cek > 0) { ?>
    <div class="container mt-5">
        <div class="row mt-5">
            <div class="col"></div>
            <div class="col-xs-12 col-sm-12 col-md-8 col-lg-12">
                <div class="card shadow">
                    <div class="card-header text-center">
                        <h5 class="card-title">
                            Daftar Visitor Belum di closing
                        </h5>
                    </div>
                    <div class="card-body">
                        <div class="text-end mb-3">
                            <button class="btn btn-primary btn-sm" onclick="listClosing()">Closing</button>
                        </div>
                        <div class="table-responsive" id="target">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Tanggal</th>
                                        <th>Nama</th>
                                        <th>Brand</th>
                                    </tr>
                                </thead>
                                <tbody id="targetClosingBody"></tbody>
                            </table>
                            <div class="paginationClosing"></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col"></div>
        </div>
    </div>

    <!-- modal -->
    <div class="modal modalOption fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Pilih Tanggal</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label for="">Pilih Tanggal</label>
                        <select name="" class="form-control" id="tanggal">
                            <?php foreach ($tanggal as $a) { ?>
                                <option value="<?= $a; ?>"><?= $a; ?></option>
                            <?php } ?>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary btn-sm" onclick="lihatClosing()">Lanjut</button>
                </div>
            </div>
        </div>
    </div>

    <div class="modal modalDetail fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Detail</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body" id="targetDetail">
                </div>

            </div>
        </div>
    </div>
    <!-- modal -->
<?php } ?>

<script>
    $(document).ready(function() {
        ambilClosing(0);

        $('.paginationClosing').on('click', 'a', function(e) {
            e.preventDefault();
            var pageno = $(this).attr('data-ci-pagination-page');
            ambilClosing(pageno);
        });
    })

    function ambilClosing(halaman) {
        // $.ajax({
        //     type: 'get',
        //     data: 'limit=10&halaman=' + halaman,
        //     url: '<?= base_url('closing/paginationClosing'); ?>',
        //     dataType: 'text',
        //     success: function(hasil) {
        //         $('#target').html(hasil);
        //     }
        // })

        $.ajax({
            type: 'GET',
            url: 'closing/paginationClosing/' + halaman,
            dataType: 'json',
            success: function(hasil) {
                $('.paginationClosing').html(hasil.pagination);
                table(hasil.hasil, hasil.brandArr, hasil.halaman, hasil.tanggal);
            }
        })
    }

    function table(hasil, brandArr, halaman, tanggal) {
        var isi = '';
        for ($i = 0; $i < hasil.length; $i++) {
            var brand = 'b' + hasil[$i].brand;
            if (brand in brandArr) {
                var brandList = brandArr[brand];
            }
            isi += '<tr>' +
                '<td>' + ++halaman + '</td>' +
                '<td>' + tanggal[$i] + '</td>' +
                '<td>' + hasil[$i].nama + '</td>' +
                '<td>' + brandList + '</td>' +
                '</tr>';
        }
        $('#targetClosingBody').html(isi);
    }

    function listClosing() {
        $('.modalOption').modal('show');
    }

    function lihatClosing() {
        var tanggal = $('#tanggal').val();
        $('.modalOption').modal('hide');
        $('.modalDetail').modal('show');

        $.ajax({
            type: 'POST',
            data: {
                tanggal: tanggal
            },
            url: '<?= base_url('closing/tampilkanClosing'); ?>',
            dataType: 'text',
            success: function(hasil) {
                $('#targetDetail').html(hasil);
                $('.modalDetail');
                ambilClosing(0);
            }
        })
    }

    function simpan(tanggal) {
        swal("Anda yakin closing data tersebut?", {
                buttons: {
                    cancel: "Tidak",
                    catch: {
                        text: "Yakin",
                        value: "yakin",
                    },
                },
            })
            .then((value) => {
                switch (value) {

                    case "yakin":
                        $.ajax({
                            type: 'POST',
                            data: 'tanggal=' + tanggal,
                            url: '<?= base_url('closing/prosesClosing'); ?>',
                            success: function(hasil) {
                                swal('Berhasil', 'Closing berhasil dilakukan', 'success', {
                                    buttons: false,
                                    timer: 900
                                })
                                $('.modalDetail').modal('hide');
                                setTimeout(function() {
                                    var url = '<?= base_url('closing'); ?>';
                                    window.location = url;
                                }, 900);
                            }
                        })
                        break;

                    default:
                        swal('Silahkan cek kembali', {
                            buttons: false,
                            timer: 700
                        });
                }
            });
    }
</script>