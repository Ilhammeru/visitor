<div class="container mt-5 pt-5">
    <div class="row">
        <div class="col"></div>
        <div class="col-md-8 col-sm-12 col-xs-12 text-center">
            <span class="spanDashboard">VISITOR</span>
        </div>
        <div class="col"></div>
    </div>
    <input type="password" style="display:none">
    <div class="row mb-5">
        <div class="col"></div>
        <div class="col-lg-10 col-md-10 col-sm-12 col-xs-12">
            <div class="input-group mb-3 ≈">
                <button class="btn btn-outline-secondary dropdown-toggle buttonDropdown" style="border-top-left-radius: 20px; border-bottom-left-radius: 20px;" type="button" data-bs-toggle="dropdown" aria-expanded="false">Hp</button>
                <ul class="dropdown-menu shadow" transparent style="background-color: rgba(77,75,75,1); border-radius: 10px; font-size: 0.8em; border: 0.05px black solid; box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
                    <li class="hp"><a class="dropdown-item text-white dropdown-home" style="cursor: pointer;" onmouseover="this.style.backgroundColor='black';" onmouseout="this.style.backgroundColor='rgba(77,75,75,0.1)';" href="#">Hp</a></li>
                    <li class="nama" id="2"><a class="dropdown-item text-white" onmouseover="this.style.backgroundColor='black';" onmouseout="this.style.backgroundColor='rgba(77,75,75,0.1)';" href="#">Nama</a></li>
                    <li>
                        <hr class="dropdown-divider">
                    </li>
                    <li class="prospek11" id="1.1"><a class="dropdown-item text-white" onmouseover="this.style.backgroundColor='black';" onmouseout="this.style.backgroundColor='rgba(77,75,75,0.1)';" href="#">Prospek 1.1</a></li>
                    <li class="prospek12" id="1.2"><a class="dropdown-item text-white" onmouseover="this.style.backgroundColor='black';" onmouseout="this.style.backgroundColor='rgba(77,75,75,0.1)';" href="#">Prospek 1.2</a></li>
                    <li class="prospek13" id="1.3"><a class="dropdown-item text-white" onmouseover="this.style.backgroundColor='black';" onmouseout="this.style.backgroundColor='rgba(77,75,75,0.1)';" href="#">Prospek 1.3</a></li>
                    <li class="prospek14" id="1.4"><a class="dropdown-item text-white" onmouseover="this.style.backgroundColor='black';" onmouseout="this.style.backgroundColor='rgba(77,75,75,0.1)';" href="#">Prospek All</a></li>
                    <li>
                        <hr class="dropdown-divider">
                    </li>
                    <li class="prospek21" id="2.1"><a class="dropdown-item text-white" onmouseover="this.style.backgroundColor='black';" onmouseout="this.style.backgroundColor='rgba(77,75,75,0.1)';" href="#">Prospek 2.1</a></li>
                    <li class="prospek22" id="2.2"><a class="dropdown-item text-white" onmouseover="this.style.backgroundColor='black';" onmouseout="this.style.backgroundColor='rgba(77,75,75,0.1)';" href="#">Prospek 2.2</a></li>
                    <li class="prospek23" id="2.3"><a class="dropdown-item text-white" onmouseover="this.style.backgroundColor='black';" onmouseout="this.style.backgroundColor='rgba(77,75,75,0.1)';" href="#">Prospek 2.3</a></li>
                    <li class="prospek24" id="2.4"><a class="dropdown-item text-white" onmouseover="this.style.backgroundColor='black';" onmouseout="this.style.backgroundColor='rgba(77,75,75,0.1)';" href="#">Prospek All</a></li>
                    <li>
                        <hr class="dropdown-divider">
                    </li>
                    <li class="prospek31" id="3.1"><a class="dropdown-item text-white" onmouseover="this.style.backgroundColor='black';" onmouseout="this.style.backgroundColor='rgba(77,75,75,0.1)';" href="#">Prospek 3.1</a></li>
                    <li class="prospek32" id="3.2"><a class="dropdown-item text-white" onmouseover="this.style.backgroundColor='black';" onmouseout="this.style.backgroundColor='rgba(77,75,75,0.1)';" href="#">Prospek 3.2</a></li>
                    <li class="prospek33" id="3.3"><a class="dropdown-item text-white" onmouseover="this.style.backgroundColor='black';" onmouseout="this.style.backgroundColor='rgba(77,75,75,0.1)';" href="#">Prospek 3.3</a></li>
                    <li class="prospek34" id="3.4"><a class="dropdown-item text-white" onmouseover="this.style.backgroundColor='black';" onmouseout="this.style.backgroundColor='rgba(77,75,75,0.1)';" href="#">Prospek All</a></li>
                </ul>
                <input type="text" id="cari" data-cari="1" class="form-control" placeholder="Ketik Nomor hp visitor (Minimal 5 karakter)" style="border-top-right-radius: 20px; border-bottom-right-radius: 20px;" aria-label="Text input with dropdown button" onfocus="this.type='text'">
            </div>
        </div>
        <div class="col"></div>
    </div>
    <div class="row">
        <div class="col"></div>
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" id="target">

        </div>
        <div class="col"></div>
    </div>

    <script>
        $(document).ready(function() {
            $('#cari').autocomplete({
                source: '<?= base_url('dashboard/autocomplete'); ?>',
                close: function(event, ui) {
                    var id = $('#cari').attr('data-cari');
                    var kunci = $('#cari').val();
                    sortingData(id, kunci);
                },
                minLength: 5
            })
        })

        function sortingData(id, kunci) {
            $.ajax({
                type: 'POST',
                data: 'no=' + kunci + '&id=' + id,
                url: '<?= base_url('dashboard/find_data/'); ?>',
                dataType: 'text',
                success: function(hasil) {
                    $('#target').html(hasil);
                }
            })
        }

        $('.hp').click(function() {
            $('#cari').attr('data-cari', 1);
            $('.buttonDropdown').text('Hp');
            $('#cari').autocomplete({
                source: '<?= base_url('dashboard/autocomplete'); ?>',
                close: function(event, ui) {
                    var id = $('#cari').attr('data-cari');
                    var kunci = $('#cari').val();
                    sortingData(id, kunci);
                },
                minLength: 5
            })
            $('#cari').attr('placeholder', 'Ketik Nomor hp visitor (Minimal 5 karakter)');
            // $('#cariData').attr('class', hp);
            $('#cari').val('');
            $('#target').html('');
        })

        $('.nama').click(function() {
            $('#cari').attr('data-cari', 2)
            $('.buttonDropdown').text('Nama');
            $('#cari').autocomplete({
                source: '<?= base_url('dashboard/autocompleteNama'); ?>',
                close: function(event, ui) {
                    var id = $('#cari').attr('data-cari');
                    var kunci = $('#cari').val();
                    sortingData(id, kunci);
                },
                minLength: 3
            })
            $('#cari').attr('placeholder', 'Ketik Nama visitor (Minimal 3 karakter)');
            // $('#cariData').attr('class', nama);
            $('#cari').val('');
            $('#target').html('');
        })

        $('.prospek11').click(function() {
            $('#cari').attr('data-cari', 11);
            $('.buttonDropdown').text('Prospek');
            $('#cari').autocomplete({
                source: '<?= base_url('dashboard/autocompleteBrand'); ?>',
                close: function(event, ui) {
                    var id = $('#cari').attr('data-cari');
                    var kunci = $('#cari').val();
                    sortingData(id, kunci);
                },
                minLength: 3
            })
            $('#cari').attr('placeholder', 'Ketik Nama Brand (Minimal 3 karakter)');
            // $('#cariData').attr('class', nama);
            $('#cari').val('');
            $('#target').html('');
        })

        $('.prospek12').click(function() {
            $('#cari').attr('data-cari', 12);
            $('.buttonDropdown').text('Prospek');
            $('#cari').autocomplete({
                source: '<?= base_url('dashboard/autocompleteBrand'); ?>',
                close: function(event, ui) {
                    var id = $('#cari').attr('data-cari');
                    var kunci = $('#cari').val();
                    sortingData(id, kunci);
                },
                minLength: 3
            })
            $('#cari').attr('placeholder', 'Ketik Nama Brand (Minimal 3 karakter)');
            // $('#cariData').attr('class', nama);
            $('#cari').val('');
            $('#target').html('');
        })

        $('.prospek13').click(function() {
            $('#cari').attr('data-cari', 13);
            $('.buttonDropdown').text('Prospek');
            $('#cari').autocomplete({
                source: '<?= base_url('dashboard/autocompleteBrand'); ?>',
                close: function(event, ui) {
                    var id = $('#cari').attr('data-cari');
                    var kunci = $('#cari').val();
                    sortingData(id, kunci);
                },
                minLength: 3
            })
            $('#cari').attr('placeholder', 'Ketik Nama Brand (Minimal 3 karakter)');
            // $('#cariData').attr('class', nama);
            $('#cari').val('');
            $('#target').html('');
        })

        $('.prospek14').click(function() {
            $('#cari').attr('data-cari', 40);
            $('.buttonDropdown').text('Prospek');
            $('#cari').autocomplete({
                source: '<?= base_url('dashboard/autocompleteBrand'); ?>',
                close: function(event, ui) {
                    var id = $('#cari').attr('data-cari');
                    var kunci = $('#cari').val();
                    sortingData(id, kunci);
                },
                minLength: 3
            })
            $('#cari').attr('placeholder', 'Ketik Nama Brand (Minimal 3 karakter)');
            // $('#cariData').attr('class', nama);
            $('#cari').val('');
            $('#target').html('');
        })

        $('.prospek21').click(function() {
            $('#cari').attr('data-cari', 21);
            $('.buttonDropdown').text('Prospek');
            $('#cari').autocomplete({
                source: '<?= base_url('dashboard/autocompleteBrand'); ?>',
                close: function(event, ui) {
                    var id = $('#cari').attr('data-cari');
                    var kunci = $('#cari').val();
                    sortingData(id, kunci);
                },
                minLength: 3
            })
            $('#cari').attr('placeholder', 'Ketik Nama Brand (Minimal 3 karakter)');
            // $('#cariData').attr('class', nama);
            $('#cari').val('');
            $('#target').html('');
        })

        $('.prospek22').click(function() {
            $('#cari').attr('data-cari', 22);
            $('.buttonDropdown').text('Prospek');
            $('#cari').autocomplete({
                source: '<?= base_url('dashboard/autocompleteBrand'); ?>',
                close: function(event, ui) {
                    var id = $('#cari').attr('data-cari');
                    var kunci = $('#cari').val();
                    sortingData(id, kunci);
                },
                minLength: 3
            })
            $('#cari').attr('placeholder', 'Ketik Nama Brand (Minimal 3 karakter)');
            // $('#cariData').attr('class', nama);
            $('#cari').val('');
            $('#target').html('');
        })

        $('.prospek23').click(function() {
            $('#cari').attr('data-cari', 23);
            $('.buttonDropdown').text('Prospek');
            $('#cari').autocomplete({
                source: '<?= base_url('dashboard/autocompleteBrand'); ?>',
                close: function(event, ui) {
                    var id = $('#cari').attr('data-cari');
                    var kunci = $('#cari').val();
                    sortingData(id, kunci);
                },
                minLength: 3
            })
            $('#cari').attr('placeholder', 'Ketik Nama Brand (Minimal 3 karakter)');
            // $('#cariData').attr('class', nama);
            $('#cari').val('');
            $('#target').html('');
        })

        $('.prospek24').click(function() {
            $('#cari').attr('data-cari', 41);
            $('.buttonDropdown').text('Prospek');
            $('#cari').autocomplete({
                source: '<?= base_url('dashboard/autocompleteBrand'); ?>',
                close: function(event, ui) {
                    var id = $('#cari').attr('data-cari');
                    var kunci = $('#cari').val();
                    sortingData(id, kunci);
                },
                minLength: 3
            })
            $('#cari').attr('placeholder', 'Ketik Nama Brand (Minimal 3 karakter)');
            // $('#cariData').attr('class', nama);
            $('#cari').val('');
            $('#target').html('');
        })

        $('.prospek31').click(function() {
            $('#cari').attr('data-cari', 31);
            $('.buttonDropdown').text('Prospek');
            $('#cari').autocomplete({
                source: '<?= base_url('dashboard/autocompleteBrand'); ?>',
                close: function(event, ui) {
                    var id = $('#cari').attr('data-cari');
                    var kunci = $('#cari').val();
                    sortingData(id, kunci);
                },
                minLength: 3
            })
            $('#cari').attr('placeholder', 'Ketik Nama Brand (Minimal 3 karakter)');
            // $('#cariData').attr('class', nama);
            $('#cari').val('');
            $('#target').html('');
        })

        $('.prospek32').click(function() {
            $('#cari').attr('data-cari', 32);
            $('.buttonDropdown').text('Prospek');
            $('#cari').autocomplete({
                source: '<?= base_url('dashboard/autocompleteBrand'); ?>',
                close: function(event, ui) {
                    var id = $('#cari').attr('data-cari');
                    var kunci = $('#cari').val();
                    sortingData(id, kunci);
                },
                minLength: 3
            })
            $('#cari').attr('placeholder', 'Ketik Nama Brand (Minimal 3 karakter)');
            // $('#cariData').attr('class', nama);
            $('#cari').val('');
            $('#target').html('');
        })

        $('.prospek33').click(function() {
            $('#cari').attr('data-cari', 33);
            $('.buttonDropdown').text('Prospek');
            $('#cari').autocomplete({
                source: '<?= base_url('dashboard/autocompleteBrand'); ?>',
                close: function(event, ui) {
                    var id = $('#cari').attr('data-cari');
                    var kunci = $('#cari').val();
                    sortingData(id, kunci);
                },
                minLength: 3
            })
            $('#cari').attr('placeholder', 'Ketik Nama Brand (Minimal 3 karakter)');
            // $('#cariData').attr('class', nama);
            $('#cari').val('');
            $('#target').html('');
        })

        $('.prospek34').click(function() {
            $('#cari').attr('data-cari', 42);
            $('.buttonDropdown').text('Prospek');
            $('#cari').autocomplete({
                source: '<?= base_url('dashboard/autocompleteBrand'); ?>',
                close: function(event, ui) {
                    var id = $('#cari').attr('data-cari');
                    var kunci = $('#cari').val();
                    sortingData(id, kunci);
                },
                minLength: 3
            })
            $('#cari').attr('placeholder', 'Ketik Nama Brand (Minimal 3 karakter)');
            // $('#cariData').attr('class', nama);
            $('#cari').val('');
            $('#target').html('');
        })


        $('#cari').keypress(function(e) {
            var keycode = (event.keyCode ? event.keyCode : event.which);
            if (keycode == '13') {
                var id = $('#cari').attr('data-cari');
                var kunci = $('#cari').val();
                if (kunci == '') {
                    swal('Kosong', 'Mohon untuk menuliskan nomor pada kolom yang tersedia', 'error');
                } else {
                    $.ajax({
                        type: 'POST',
                        data: 'no=' + kunci + '&id=' + id,
                        url: '<?= base_url('dashboard/find_data/'); ?>',
                        dataType: 'text',
                        success: function(hasil) {
                            if (hasil == '') {
                                swal('Harap masukan Nomor dengan benar');
                            } else {
                                $('#target').html(hasil);
                            }
                        }
                    })
                }
            }
            e.stopPropagation();
        })
    </script>