<!-- <div class="container mt-5">
    <div class="row">
        <div class="col"></div>
        <div class="col-md-10 col-sm-12 col-xs-12"> -->
<div class="card shadow" style="max-height: 80%">
    <div class="card-header text-center">
        <h5 class="card-title">Tambah data</h5>
    </div>
    <div class="table-responsive">
        <div class="card-body">
            <div class="row mb-3">
                <label for="" class="col-form-label col-sm-4 col-form-label-sm">Tanggal</label>
                <div class="col-sm-8">
                    <input type="text" class="form-control form-control-sm" id="tanggalVisit" placeholder="Pilih tanggal Visit">
                </div>
            </div>
            <div class="row mb-3" hidden>
                <label for="" class="col-form-label col-sm-4 col-form-label-sm">Department</label>
                <div class="col-sm-8">
                    <input type="text" class="form-control form-control-sm border-0 bg-white" readonly id="pt">
                </div>
            </div>
            <div class="row mb-3">
                <label for="" class="col-form-label col-sm-4 col-form-label-sm">Marketing</label>
                <div class="col-sm-8">
                    <select id="marketing" class="form-control form-control-sm" readonly>

                    </select>
                </div>
            </div>
            <div class="row mb-3">
                <label for="" class="col-form-label col-sm-4 col-form-label-sm">Brand</label>
                <div class="col-sm-8">
                    <select id="brand" class="form-control form-control-sm" readonly>

                    </select>
                </div>
            </div>
            <div class="row mb-3">
                <label for="" class="col-form-label col-sm-4 col-form-label-sm">Nomor Telfon</label>
                <div class="col-sm-8">
                    <input type="text" class="form-control form-control-sm" id="hp" placeholder="Diawali dengan angka 0, Ex: 08976076029" onchange="ubahJKdanUmur()">
                </div>
            </div>
            <div class="row mb-3">
                <label for="" class="col-form-label col-sm-4 col-form-label-sm">Nama Visitor</label>
                <div class="col-sm-8">
                    <input type="text" class="form-control form-control-sm" id="nama">
                </div>
            </div>
            <div class="row mb-3">
                <label for="" class="col-form-label col-sm-4 col-form-label-sm">Jenis Kelamin</label>
                <div class="col-sm-8">
                    <div class="form-check">
                        <input class="form-check-input " type="radio" name="jenisKelamin" id="laki" value="l">
                        <label class="form-check-label" for="laki">
                            Laki - laki
                        </label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="radio" name="jenisKelamin" id="perempuan" value="p">
                        <label class="form-check-label" for="perempuan">
                            Perempuan
                        </label>
                    </div>
                </div>
            </div>
            <div class="row mb-3">
                <label for="" class="col-form-label col-form-label-sm col-sm-4">Umur</label>
                <div class="col-sm-8">

                    <div class="form-check">
                        <input class="form-check-input" type="radio" name="umur" id="30" value="1">
                        <label class="form-check-label" for="30">
                            < 20 tahun</label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="radio" name="umur" id="30" value="2">
                        <label class="form-check-label" for="30">20 - 30 tahun</label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="radio" name="umur" id="30" value="3">
                        <label class="form-check-label" for="30">30 - 40 tahun</label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="radio" name="umur" id="atas" value="4">
                        <label class="form-check-label" for="atas">> 40 tahun</label>
                    </div>
                </div>
            </div>
            <div class="row mb-3">
                <label for="" class="col-form-label col-form-label-sm col-sm-4">Kota / Provinsi</label>
                <div class="col-sm-4">
                    <select name="" class="form-control form-control-sm" id="cariKota" onchange="ubahKota()">
                        <option value="">-- Pilih --</option>
                        <?php foreach ($kota as $row) { ?>
                            <option value="<?= $row->id_city; ?>"><?= $row->city_name; ?></option>
                        <?php } ?>
                    </select>
                </div>
                <div class="col-sm-4">
                    <select name="" class="form-control form-control-sm" id="prov" readonly>
                        <option value="" id="targetProv"></option>
                    </select>
                </div>
            </div>
            <div class="row mb-3">
                <label for="" class="col-form-label col-form-label-sm col-sm-4">Kategori</label>
                <div class="col-sm-8">
                    <select name="" class="form-control form-control-sm" id="kategori" onchange="ubahProspek()">
                        <option value="3">Respon</option>
                        <option value="2">No Respon</option>
                        <option value="1">Anak - anak</option>
                    </select>
                </div>
            </div>
            <div class="row mb-3" id="quoteGroup">
                <label for="" class="col-form-label col-form-label-sm col-sm-4">Prospek</label>
                <div class="col-sm-8">
                    <div class="table-responsive">
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" name="rating" type="radio" id="inlineCheckbox1" value="1">
                            <label class="form-check-label" for="inlineCheckbox1">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="30" fill="gold" class="bi bi-star-fill" viewBox="0 0 16 16">
                                    <path d="M3.612 15.443c-.386.198-.824-.149-.746-.592l.83-4.73L.173 6.765c-.329-.314-.158-.888.283-.95l4.898-.696L7.538.792c.197-.39.73-.39.927 0l2.184 4.327 4.898.696c.441.062.612.636.283.95l-3.523 3.356.83 4.73c.078.443-.36.79-.746.592L8 13.187l-4.389 2.256z" />
                                </svg>
                            </label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" name="rating" type="radio" id="inlineCheckbox2" value="2">
                            <label class="form-check-label" for="inlineCheckbox2">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="30" fill="gold" class="bi bi-star-fill" viewBox="0 0 16 16">
                                    <path d="M3.612 15.443c-.386.198-.824-.149-.746-.592l.83-4.73L.173 6.765c-.329-.314-.158-.888.283-.95l4.898-.696L7.538.792c.197-.39.73-.39.927 0l2.184 4.327 4.898.696c.441.062.612.636.283.95l-3.523 3.356.83 4.73c.078.443-.36.79-.746.592L8 13.187l-4.389 2.256z" />
                                </svg>
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="30" fill="gold" class="bi bi-star-fill" viewBox="0 0 16 16">
                                    <path d="M3.612 15.443c-.386.198-.824-.149-.746-.592l.83-4.73L.173 6.765c-.329-.314-.158-.888.283-.95l4.898-.696L7.538.792c.197-.39.73-.39.927 0l2.184 4.327 4.898.696c.441.062.612.636.283.95l-3.523 3.356.83 4.73c.078.443-.36.79-.746.592L8 13.187l-4.389 2.256z" />
                                </svg>
                            </label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" name="rating" type="radio" id="inlineCheckbox3" value="3">
                            <label class="form-check-label" for="inlineCheckbox3">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="30" fill="gold" class="bi bi-star-fill" viewBox="0 0 16 16">
                                    <path d="M3.612 15.443c-.386.198-.824-.149-.746-.592l.83-4.73L.173 6.765c-.329-.314-.158-.888.283-.95l4.898-.696L7.538.792c.197-.39.73-.39.927 0l2.184 4.327 4.898.696c.441.062.612.636.283.95l-3.523 3.356.83 4.73c.078.443-.36.79-.746.592L8 13.187l-4.389 2.256z" />
                                </svg>
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="30" fill="gold" class="bi bi-star-fill" viewBox="0 0 16 16">
                                    <path d="M3.612 15.443c-.386.198-.824-.149-.746-.592l.83-4.73L.173 6.765c-.329-.314-.158-.888.283-.95l4.898-.696L7.538.792c.197-.39.73-.39.927 0l2.184 4.327 4.898.696c.441.062.612.636.283.95l-3.523 3.356.83 4.73c.078.443-.36.79-.746.592L8 13.187l-4.389 2.256z" />
                                </svg>
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="30" fill="gold" class="bi bi-star-fill" viewBox="0 0 16 16">
                                    <path d="M3.612 15.443c-.386.198-.824-.149-.746-.592l.83-4.73L.173 6.765c-.329-.314-.158-.888.283-.95l4.898-.696L7.538.792c.197-.39.73-.39.927 0l2.184 4.327 4.898.696c.441.062.612.636.283.95l-3.523 3.356.83 4.73c.078.443-.36.79-.746.592L8 13.187l-4.389 2.256z" />
                                </svg>
                            </label>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row" id="alasanGroup">
                <?php if ($jAlasan != 0) { ?>
                    <label for="" class="col-form-label col-sm-4 col-form-label-sm">Alasan</label>
                    <div class="col-sm-8">
                        <?php foreach ($alasan as $a) { ?>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="radioAlasan" value="<?= $a->id; ?>" id="alasan">
                                <label class="form-check-label" for="alasan">
                                    <?= $a->alasan; ?>
                                </label>
                            </div>
                        <?php } ?>
                    </div>
                <?php } else { ?>
                    <div class="alert alert-danger" role="alert">
                        <p>Database alasan belum ada, Silahkan tambah alasan terlebih dahulu</p>
                    </div>
                <?php } ?>
            </div>
        </div>
    </div>
    <div class="card-footer">
        <div class="row mb-3">
            <div class="col"></div>
            <div class="col col-md-6 col-sm-12">
                <button class="btn btn-primary btn-sm w-100" onclick="simpan()" <?= ($jAlasan == 0) ? 'disabled' : ''; ?>>Simpan Data</button>
            </div>
            <div class="col"></div>
        </div>
    </div>
</div>
<!-- </div>
        <div class="col"></div>
    </div>
</div> -->

<script>
    $(document).ready(function() {
        $('#tanggalVisit').datepicker({
            format: 'yyyy-mm-dd',
            todayBtn: true,
            todayHighlight: true,
            autoclose: true
        })
        $.ajax({
            type: 'POST',
            url: '<?= base_url('visitor/ambilPt'); ?>',
            dataType: 'text',
            success: function(hasil) {
                $('#pt').val(hasil);
                $.ajax({
                    type: 'POST',
                    data: 'id=' + <?= $_SESSION['pt']; ?>,
                    url: '<?= base_url('visitor/ambilNama'); ?>',
                    dataType: 'json',
                    success: function(hasil) {
                        var isi = '';
                        for ($i = 0; $i < hasil.length; $i++) {
                            isi += '<option value="' + hasil[$i].id + '">' + hasil[$i].name + '</option>';
                        }
                        $('#marketing').html(isi);
                        $('#marketing').removeAttr('readonly');
                        $.ajax({
                            type: 'POST',
                            data: 'id=' + <?= $_SESSION['pt']; ?>,
                            url: '<?= base_url('visitor/ambilBrand'); ?>',
                            dataType: 'json',
                            success: function(brand) {
                                var baris = '';
                                for ($u = 0; $u < brand.length; $u++) {
                                    baris += '<option value="' + brand[$u].id_franchise + '">' + brand[$u].nama_franchise + '</option>';
                                }
                                $('#brand').html(baris);
                                $('#brand').removeAttr('readonly');
                            }
                        })
                    }
                })
            }
        })

        $('#hp').autocomplete({
            source: '<?= base_url('dashboard/autocomplete'); ?>'
        })

        $('#cariKota').select2();
    })

    function ubahJKdanUmur() {
        var hp = $('#hp').val();
        $.ajax({
            type: 'POST',
            data: {
                hp: hp
            },
            url: '<?= base_url('visitor/cekDataDenganHp'); ?>',
            dataType: 'json',
            success: function(hasil) {
                if (hasil != 'tidak ada') {
                    $('input[value="' + hasil[0].j_kelamin + '"]').prop('checked', true);
                    $('input[value="' + hasil[0].umur + '"]').prop('checked', true);
                    $('input[name="rating"]').prop('checked', false);
                }
            }
        })
    }

    function ubahProspek() {
        var kategori = $('#kategori').val();
        if (kategori != 3) {
            $('#quoteGroup').fadeOut(100);
            $('#alasanGroup').fadeOut(100);
            $('input[name="rating"]:checked').val('0');
            $('input[name="radioAlasan"]:checked').val('0');
        } else {
            $('#quoteGroup').fadeIn(300);
            $('#alasanGroup').fadeIn(100);
            $('input[name="rating"]:checked').prop('checked', false);
        }
    }

    function ubahKota() {
        var idKota = $('#cariKota').val();
        $.ajax({
            type: 'POST',
            data: {
                id: idKota
            },
            url: '<?= base_url('visitor/ambilProv'); ?>',
            dataType: 'text',
            success: function(hasil) {
                $('#targetProv').text(hasil);
            }
        })
    }

    function simpan() {
        var nama = $('#nama').val();
        var hp = $('#hp').val();
        var marketing = $('#marketing').val();
        var perusahaan = <?= $_SESSION['pt']; ?>;
        var brand = $('#brand').val();
        var alasan = $('input[name="radioAlasan"]:checked').map(function() {
            return $(this).val();
        }).toArray();
        var kelamin = $('input[name="jenisKelamin"]:checked').val();
        var umur = $('input[name="umur"]:checked').val();
        var kota = $('#cariKota').val();
        var kategori = $('select[id="kategori"]').val();
        var prospek = $('input[name="rating"]:checked').map(function() {
            return $(this).val();
        }).toArray();
        var tanggal = $('#tanggalVisit').val();


        if (nama == '') {
            swal('Error', 'Nama harus diisi', 'error', {
                timer: 900,
                buttons: false
            });
        } else if (hp == '') {
            swal('Error', 'No Telfon harus diisi', 'error', {
                timer: 900,
                buttons: false
            });
        } else if (alasan == '') {
            swal('Error', 'Setidaknya pilih salah satu alasan', 'error', {
                timer: 900,
                buttons: false
            });
        } else if (marketing == '') {
            swal('Error', 'Nama marketing harus diisi', 'error', {
                timer: 900,
                buttons: false
            });
        } else if (perusahaan == '') {
            swal('Error', 'Perusahaan harus diisi', 'error', {
                timer: 900,
                buttons: false
            });
        } else if (brand == '') {
            swal('Error', 'Brand harus diisi', 'error', {
                timer: 900,
                buttons: false
            });
        } else if (kelamin == '') {
            swal('Error', 'Kolom jenis kelamin masih kosong', 'error', {
                timer: 900,
                buttons: false
            });
        } else if (umur == '') {
            swal('Error', 'Umur belum diisi', 'error', {
                timer: 900,
                buttons: false
            });
        } else if (kota == '') {
            swal('Error', 'Kota belum diisi', 'error', {
                timer: 900,
                buttons: false
            });
        } else if (kategori == '') {
            swal('Error', 'Kategori belum diisi', 'error', {
                timer: 900,
                buttons: false
            });
        } else if (prospek == '') {
            swal('Error', 'Prospek belum diisi', 'error', {
                timer: 900,
                buttons: false
            });
        } else if (tanggal == '') {
            swal('Error', 'Tanggal belum diisi', 'error', {
                timer: 900,
                buttons: false
            });
        } else {
            //cek hp dan brand apakah sudah ada di database atau belum
            swal("Anda yakin ingin menyimpan data ini?", {
                    buttons: {
                        catch: {
                            text: 'Yakin',
                            value: 'yakin',
                        },
                        cancel: 'Belum',
                    },
                })
                .then((value) => {
                    switch (value) {

                        case "yakin":
                            $.ajax({
                                type: 'POST',
                                data: 'nama=' + nama + '&hp=' + hp + '&marketing=' + marketing + '&perusahaan=' + perusahaan + '&brand=' + brand + '&alasan=' + alasan + '&kelamin=' + kelamin + '&umur=' + umur + '&kota=' + kota + '&kategori=' + kategori + '&prospek=' + prospek + '&tanggal=' + tanggal,
                                url: '<?= base_url('visitor/tambahVisitor'); ?>',
                                dataType: 'text',
                                success: function(data) {
                                    if (data == 'Data sama') {
                                        swal('Gagal', 'Brand dan nomor hp sudah ada di database', 'error');
                                    } else {
                                        swal('Berhasil', 'Data berhasil diinput ke database', 'success', {
                                            timer: 900,
                                            buttons: false
                                        });
                                        $('#nama').val('');
                                        $('#hp').val('');
                                        $('input[type="checkbox"]').prop('checked', false);
                                        $('input[type="radio"]').prop('checked', false);
                                        $('#cariKota').val('');
                                        $('#targetProv').text('');
                                        $('#quoteGroup').fadeIn(100);
                                        $('#alasanGroup').fadeIn(100);
                                        $('select[id="kategori"]:checked').val('3');
                                    }
                                }
                            })
                            break;

                        default:
                            swal("Silahkan cek kembali");
                    }
                })
        }
    }
</script>