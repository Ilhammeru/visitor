<div class="container mt-5 pt-4">
    <div class="row">
        <div class="col-lg-3 col-md-12 col-sm-12 mb-3">
            <ul class="nav flex-column">
                <li class="nav-item mb-3">
                    <button class="btn btn-light btn-sm nav-link w-50" id="tambah">Tambah</button>
                </li>
                <li class="nav-item mb-2">
                    <button class="btn btn-light btn-sm nav-link w-50" id="visitor">Visitor</button>
                </li>
                <?php if ($_SESSION['role'] < 3) { ?>
                    <li class="nav-item" id="cariTanggalGroup" hidden>
                        <button class="btn btn-primary btn-sm nav-link bulanan w-50" style="font-size: 0.7em;" data-bs-toggle="collapse" id="aria" role="button" href="#cariTanggal" aria-expanded="false" aria-controls="cariBulanan">Pilih Tanggal</button>
                    </li>
                    <div class="collapse mb-2" id="cariTanggal" style="font-size: 0.8em;">
                        <div class="table-responsive">
                            <div class="row">
                                <div class="col">
                                    <div class="form-group mb-1">
                                        <label for="">Pilih Tanggal</label>
                                        <input type="text" class="form-control w-100" name="daterangepicker">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php } ?>
            </ul>
        </div>
        <div class="col-lg-9 col-md-12 col-sm-12" id="masterVisitor" hidden>
        </div>
        <div class="col-lg-9 col-md-12 col-sm-12" id="masterVisitor1" hidden>
            <div class="card shadow">
                <div class="card-header text-center">
                    <h5 class="card-title">Detail</h5>
                </div>
                <div class="card-body">
                    <div class="row mb-3">
                        <div class="col"></div>
                        <div class="col-md-6 col-sm-12 tanggalCari">

                        </div>
                        <div class="col"></div>
                    </div>
                    <?php if ($_SESSION['role'] < 3) { ?>
                        <div class="row">
                            <div class="col-md-7 col-sm-12 col-xs-12"></div>
                            <div class="col-md-5 col-sm-12 col-xs-12">
                                <div class="text-end">
                                    <form class="d-flex">
                                        <input class="form-control form-control-sm" id="cari" type="search" placeholder="Search" aria-label="Search" oninput="triggerPencarian()">
                                        <button class="btn rounded-circle text-primary" type="submit" id="sorting"><i class="fas fa-search"></i></button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    <?php } ?>
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Tanggal</th>
                                    <th>Nama</th>
                                    <th>Hp</th>
                                    <th>Brand</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody id="targetBody"></tbody>
                        </table>
                        <div class="paginationDefault"></div>
                        <div class="paginationTanggal"></div>
                        <?php if ($_SESSION['role'] < 3) { ?>
                            <div class="closing text-end mt-3 mb-3" hidden>
                                <button class="btn btn-sm" style="border-radius: 10px; background-color: #71C1D8" id="closing">Closing </button>
                            </div>
                        <?php } ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- modal -->
<div class="modal modalEdit fade" id="exampleModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-scrollable ">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Edit Data</h5>
            </div>
            <div class="modal-body" id="targetModal">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary" id="editVisit">Edit</button>
                <button type="button" class="btn btn-success" onclick="tutup()">Tutup</button>
            </div>
        </div>
    </div>
</div>

<div class="modal modalClosing fade" id="exampleModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Closing data</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="targetClosing">

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary btn-sm" onclick="btnClosing('<?= date('Y-m-d'); ?>')">Closing</button>
            </div>
        </div>
    </div>
</div>
<!-- modal -->

<script>
    $(document).ready(function() {
        $('.datepicker').datepicker({
            format: 'MM, yyyy',
            startView: 'months',
            minViewMode: 'months',
            autoclose: true
        })

        $(function() {
            $('input[name="daterangepicker"]').daterangepicker({
                opens: 'left',
                showDropdowns: true,
                autoApply: true,
                locale: {
                    format: 'YYYY-MM-DD'
                }
            }, function(start, end, label) {
                var awal = start.format('YYYY-MM-DD');
                var akhir = end.format('YYYY-MM-DD');
                cariTanggal(awal, akhir, 0);
            });
        })

        $('.paginationDefault').on('click', 'a', function(e) {
            e.preventDefault();
            var pageno = $(this).attr('data-ci-pagination-page');
            ambilVisit(pageno);
        });

        $('.paginationTanggal').on('click', 'a', function(e) {
            e.preventDefault();
            var tanggalawal = $(this).attr('tanggalawal');
            var tanggalakhir = $(this).attr('tanggalakhir');
            var halaman = $(this).attr('data-ci-pagination-page');
            cariTanggal(tanggalawal, tanggalakhir, halaman);
        });

        // $(document).on('click', '.pagination li a', function() {
        //     var halaman = $(this).attr('data-page');
        //     ambilVisit(halaman);
        // })

        $('#tambah').click(function() {
            $(this).attr('class', 'btn btn-primary btn-sm nav-link w-50');
            $('#visitor').attr('class', 'btn btn-light btn-sm nav-link w-50');
            $('#cariTanggalGroup').prop('hidden', true);
            $('#cariKategoriGroup').prop('hidden', true);
            $('#cariTanggal').attr('class', 'collapse');
            $.ajax({
                type: 'POST',
                url: '<?= base_url('visitor/tambahVisit'); ?>',
                dataType: 'text',
                success: function(hasil) {
                    $('#masterVisitor').fadeIn(100);
                    $('#masterVisitor').html(hasil);
                    $('#masterVisitor').removeAttr('hidden');
                }
            })
        })

        $('#visitor').click(function() {
            $(this).attr('class', 'btn btn-primary btn-sm nav-link w-50');
            $('#tambah').attr('class', 'btn btn-light btn-sm nav-link w-50');
            $('#cariTanggalGroup').removeAttr('hidden');
            $('#cariKategoriGroup').removeAttr('hidden');
            $('.paginationTanggal').html('');
            $('.tanggalCari').fadeOut('slow');
            ambilVisit(0);
        })

        $('#closing').click(function() {
            $('.modalClosing').modal('show');
            $.ajax({
                type: 'POST',
                url: '<?= base_url('visitor/closing'); ?>',
                dataType: 'text',
                success: function(hasil) {
                    $('#targetClosing').html(hasil);
                }
            })
        })
    })

    function cariTanggal(tanggalAwal, tanggalAkhir, halaman) {
        $.ajax({
            type: 'GET',
            dataType: 'json',
            beforeSend: function() {
                var loading = '<p>Loading....</p>';
                $('#masterVisitor').html(loading);
                $('#targetJumlah').removeAttr('hidden');
                $('#cariTanggal').attr('class', 'collapse');
            },
            success: function(data) {
                if (data == 'tidak ada data') {
                    var isi = '<tr class="text-center fst-italic">' +
                        '<td colspan="6">Belum ada data</td>' +
                        '</tr>';
                    $('#masterVisitor1').removeAttr('hidden');
                    $('#targetBody').html(isi);
                } else {
                    // $('#masterVisitor').html(data);
                    var tanggalCari = data.tglTitleA + ' - ' + data.tglTitleK;
                    $('#targetJumlah').removeAttr('hidden');
                    $('#cariTanggal').attr('class', 'collapse');
                    $('.closing').prop('hidden', true);
                    $('#targetBody').html('');
                    $('.paginationTanggal').fadeIn('slow');
                    $('.paginationTanggal').html(data.pagination);
                    $('.paginationTanggal a').attr('tanggalawal', tanggalAwal);
                    $('.paginationTanggal a').attr('tanggalakhir', tanggalAkhir);
                    $('.paginationDefault').html('');
                    $('.tanggalCari').html(tanggalCari);
                    table(data.hasil, data.halaman, data.brandArray, data.tanggal, data.isClose, data.join);
                }
            }
        })
    }

    function triggerPencarian() {
        var data = $('#cari').val();
        if (data == '') {
            ambilVisit(0);
            $('#closing').removeAttr('hidden');
        } else {
            $.ajax({
                type: 'POST',
                data: {
                    data: data
                },
                url: '<?= base_url('visitor/sortingData'); ?>',
                dataType: 'text',
                beforeSend: function() {
                    var loading = '<p>Loading ....</p>';
                    $('.tableBody').prop('hidden', true);
                    $('.targetSorting').html(loading);
                    $('.targetSorting').removeAttr('hidden');
                    $('.tfoot').prop('hidden', true);
                    $('#closing').prop('hidden', true);
                },
                success: function(hasil) {
                    $('#targetBody').html(hasil);
                    $('.paginationDefault').html('');
                    $('.paginationTanggal').html('');
                    // $('#masterVisitor1').html('');
                }
            })
        }
    }


    function tambahVisit() {
        $('.modal').modal('show');
    }

    function ambilVisit(halaman) {
        $.ajax({
            type: 'GET',
            url: '<?= site_url(); ?>/visitor/ambilVisitPagination/' + halaman,
            dataType: 'json',
            success: function(hasil) {
                if (hasil == 'tidak ada data') {
                    var isi = '<tr class="text-center fst-italic">' +
                        '<td colspan="6">Belum ada data</td>' +
                        '</tr>';
                    $('#masterVisitor1').removeAttr('hidden');
                    $('#targetBody').html(isi);

                } else {
                    // $('#masterVisitor').html(hasil);
                    // $('#masterVisitor').removeAttr('hidden');
                    if (hasil.closing > 0) {
                        $('.closing').removeAttr('hidden');
                    }
                    $('#masterVisitor1').removeAttr('hidden');
                    $('.paginationDefault').html(hasil.pagination);
                    table(hasil.hasil, hasil.halaman, hasil.brandArray, hasil.tanggal, hasil.isClose, hasil.join);
                }
            }
        })
    }

    function table(hasil, halaman, brandArr, tanggal, isClose, join) {
        var isi = '';
        for ($i = 0; $i < hasil.length; $i++) {
            var brand = 'b' + hasil[$i].brand;
            if (brand in brandArr) {
                var brandList = brandArr[brand];
            }
            if (isClose[$i] > 0) {
                var is = '<span style="font-size: 0.8em;" class="fst-italic">Sudah Closing</span>';
            } else if (join[$i] != null) {
                var is = '<span style="font-size: 0.8em;" class="fst-italic text-success">Sudah Join</span>';
            } else {
                var is = '<div class="btn-group" role="group">' +
                    '<a class="btn btn-sm text-warning" onclick="edit(' + hasil[$i].id_visit + ')"><i class="fas fa-pen"></i></a>' +
                    '<a class="btn btn-sm text-danger" onclick="hapusVisitor(' + hasil[$i].id_visit + ')"><i class="fas fa-trash"></i></a>' +
                    '</div>';
            }
            isi += '<tr>' +
                '<td>' + ++halaman + '</td>' +
                '<td>' + tanggal[$i] + '</td>' +
                '<td>' + hasil[$i].nama + '</td>' +
                '<td>' + hasil[$i].hp + '</td>' +
                '<td>' + brandList + '</td>' +
                '<td>' + is + '</td>' +
                '</tr>';
        }
        $('#targetBody').html(isi);
    }

    function hapusVisitor(id) {
        swal({
                title: "Hapus data",
                text: 'Yakin ingin menghapus data ini?',
                icon: "warning",
                buttons: true,
                dangerMode: true,
            })
            .then((willDelete) => {
                if (willDelete) {
                    $.ajax({
                        type: 'POST',
                        data: 'id=' + id + '&table=visit',
                        url: '<?= base_url('visitor/hapus'); ?>',
                        success: function() {
                            ambilVisit();
                            swal('Berhasil', 'Data berhasil di hapus', 'success', {
                                timer: 900,
                                buttons: false
                            });
                        }

                    })
                } else {
                    swal("Data anda aman");
                }
            })
    }

    function edit(id) {
        $('.modalEdit').modal('show');
        $.ajax({
            type: 'POST',
            data: {
                id: id
            },
            url: '<?= base_url('visitor/ambilDetail'); ?>',
            dataType: 'text',
            success: function(hasil) {
                $('#targetModal').html(hasil);
                $('#editVisit').attr('onclick', 'prosesEdit(' + id + ')');
                $.ajax({
                    type: 'POST',
                    data: 'id=' + id,
                    url: '<?= base_url('visitor/ambilAlasan'); ?>',
                    dataType: 'json',
                    success: function(data) {
                        console.log(data);
                        $('input[id="alasanEdit' + data[0].alasan + '"]').prop('checked', true);
                        $('#kategoriOptionEdit').val(data[0].kategori);
                        $('input[id="umurEdit' + data[0].umur + '"]').prop('checked', true);
                        $('input[id="rating' + data[0].prospek + '"]').prop('checked', true);
                    }
                })
            }
        })
    }

    function tutup() {
        $('.modal').modal('hide');
        $('#nama').val('');
        $('#hp').val('');
        $('#targetMarketing').val('');
        $('#targetPerusahaan').val('');
        $('#targetBrand').val('');
        $('input[type="checkbox"]').prop('checked', false);
    }

    function brand() {
        var department = $('#perusahaan').val();
        if (department == '') {
            $('#brand').html('');
            $('#brand').attr('readonly', '');
            $('#marketing').html('');
            $('#marketing').attr('readonly', '');
        }
        $.ajax({
            type: 'POST',
            data: {
                id: department
            },
            url: '<?= base_url('visitor/ambilNama'); ?>',
            dataType: 'json',
            success: function(hasil) {
                var isi = '';
                for ($i = 0; $i < hasil.length; $i++) {
                    isi += '<option value="' + hasil[$i].id + '">' + hasil[$i].name + '</option>';
                }
                $('#marketing').html(isi);
                $('#marketing').removeAttr('readonly');
                $.ajax({
                    type: 'POST',
                    data: {
                        id: department
                    },
                    url: '<?= base_url('visitor/ambilBrand'); ?>',
                    dataType: 'json',
                    success: function(brand) {
                        var baris = '';
                        for ($u = 0; $u < brand.length; $u++) {
                            baris += '<option value="' + brand[$u].id + '">' + brand[$u].nama_franchise + '</option>';
                        }
                        $('#brand').html(baris);
                        $('#brand').removeAttr('readonly');
                    }
                })
            }
        })
    }

    function prosesEdit(id) {
        var nama = $('#nama').val();
        var hp = $('#hp').val();
        var marketing = $('#marketing').val();
        var perusahaan = $('#perusahaan').val();
        var brand = $('#brand').val();
        var alasan = $('input[name="radioEditAlasan"]:checked').val();
        var umur = $('input[name="umur"]:checked').val();
        var kategori = $('#kategoriSelectEdit').val();
        var prospek = $('input[name="ratingEdit"]:checked').val();

        if (nama == '') {
            swal('Error', 'Nama harus diisi', 'error');
        } else if (hp == '') {
            swal('Error', 'No Telfon harus diisi', 'error');
        } else if (alasan == '') {
            swal('Error', 'Setidaknya pilih salah satu alasan', 'error');
        } else if (marketing == '') {
            swal('Error', 'Nama marketing harus diisi');
        } else if (perusahaan == '') {
            swal('Error', 'Perusahaan harus diisi');
        } else {
            //cek hp dan brand apakah sudah ada di database atau belum
            swal("Anda yakin ingin menyimpan data ini?", {
                    buttons: {
                        catch: {
                            text: 'Yakin',
                            value: 'yakin',
                        },
                        cancel: 'Belum',
                    },
                })
                .then((value) => {
                    switch (value) {

                        case "yakin":
                            $.ajax({
                                type: 'POST',
                                data: 'nama=' + nama + '&hp=' + hp + '&marketing=' + marketing + '&perusahaan=' + perusahaan + '&brand=' + brand + '&alasan=' + alasan + '&id=' + id + '&umur=' + umur + '&kategori=' + kategori + '&prospek=' + prospek,
                                url: '<?= base_url('visitor/editVisitor'); ?>',
                                dataType: 'text',
                                success: function(data) {
                                    if (data == 'brand sama') {
                                        swal("Anda yakin ingin menyimpan data dengan brand yang sama?", {
                                                buttons: {
                                                    catch: {
                                                        text: 'Yakin',
                                                        value: 'yakin',
                                                    },
                                                    cancel: 'Belum',
                                                },
                                            })
                                            .then((value) => {
                                                switch (value) {
                                                    case "yakin":
                                                        $.ajax({
                                                            type: 'POST',
                                                            data: 'nama=' + nama + '&hp=' + hp + '&marketing=' + marketing + '&perusahaan=' + perusahaan + '&brand=' + brand + '&alasan=' + alasan + '&id=' + id + '&umur=' + umur + '&kategori=' + kategori + '&prospek=' + prospek,
                                                            url: '<?= base_url('visitor/editVisitor2'); ?>',
                                                            dataType: 'text',
                                                            success: function() {
                                                                swal('Berhasil', 'Data berhasil diinput ke database', 'success', {
                                                                    timer: 900,
                                                                    buttons: false
                                                                });
                                                                $('#nama').val('');
                                                                $('#hp').val('');
                                                                $('#department').val('');
                                                                $('#marketing').html('');
                                                                $('#brand').html('');
                                                                $('#marketing').attr('readonly', '');
                                                                $('#brand').attr('readonly', '');
                                                                $('input[type="checkbox"]').prop('checked', false);
                                                                $('.modal').modal('hide');
                                                                ambilVisit();
                                                            }
                                                        })
                                                        break;
                                                    default:
                                                        swal("Silahkan cek kembali");
                                                }
                                            })
                                    } else {
                                        swal('Berhasil', 'Data berhasil diinput ke database', 'success', {
                                            timer: 900,
                                            buttons: false
                                        });
                                        $('#nama').val('');
                                        $('#hp').val('');
                                        $('#department').val('');
                                        $('#marketing').html('');
                                        $('#brand').html('');
                                        $('#marketing').attr('readonly', '');
                                        $('#brand').attr('readonly', '');
                                        $('input[type="checkbox"]').prop('checked', false);
                                        $('.modal').modal('hide');
                                        ambilVisit();
                                    }
                                }
                            })
                            break;

                        default:
                            swal("Silahkan cek kembali");
                    }
                })
        }
    }
</script>