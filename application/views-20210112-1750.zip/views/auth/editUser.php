<?php foreach ($hasil as $row) : ?>
    <div class="row mb-3">
        <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="form-group">
                <label for="">Nama</label>
                <input type="text" id="namaEdit" class="form-control" value="<?= $row->nama_user; ?>">
            </div>
        </div>
    </div>
    <div class="row mb-3">
        <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="form-group">
                <label for="">Aksesbilitas</label>
                <select name="" class="form-control" id="aksesEdit">
                    <optgroup label="Pilihan Sebelumnya">
                        <option value="<?= $row->role; ?>"><?= $row->status; ?></option>
                    </optgroup>
                    <optgroup label="Data">
                        <option value="1">Admin</option>
                        <option value="2">User</option>
                    </optgroup>
                </select>
            </div>
        </div>
    </div>
    <div class="row mb-3">
        <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="form-group">
                <label for="">Perusahaan</label>
                <select name="" class="form-control" id="ptEdit">
                    <optgroup label="Pilihan sebelumnya">
                        <?php if (isset($pt['p' . $row->pt])) { ?>
                            <option value="<?= $row->pt; ?>"><?= $pt['p' . $row->pt]; ?></option>
                        <?php } ?>
                    </optgroup>
                    <optgroup label="Data">
                        <?php foreach ($daftarPt as $dp) { ?>
                            <option value="<?= $dp->id; ?>"><?= $dp->name; ?></option>
                        <?php } ?>
                    </optgroup>
                </select>
            </div>
        </div>
    </div>
<?php endforeach; ?>