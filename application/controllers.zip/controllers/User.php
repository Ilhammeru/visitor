<?php
defined('BASEPATH') or exit('No direct script allowed');
class User extends CI_Controller
{
    public function cekUser()
    {
        $id = $this->input->post('id');
        $hasil = ambilWhere(array('id' => $id), 'user')->result();
        echo json_encode($hasil);
    }

    public function hapus()
    {
        $id = $this->input->post('id');
        hapus('user', array('id' => $id));
    }

    public function ambilUser()
    {
        $idPt = $_SESSION['pt'];
        if ($_SESSION['role'] == 1) {
            $user = $this->db->query("SELECT nama_user, status, pt, id FROM user WHERE pt = $idPt")->result();
        } else if ($_SESSION['role'] == 0) {
            $user = $this->db->query("SELECT nama_user, status, pt, id FROM user")->result();
        }

        $db = $this->load->database('we', true);
        $pt = $db->query('SELECT name, id FROM ansena_department WHERE income = 1')->result();
        $ptArr = array();
        foreach ($pt as $row) {
            $ptArr['p' . $row->id] = $row->name;
        }
        $db->close();

        $data = [
            'hasil' => $user,
            'pt'    => $ptArr
        ];

        $this->load->view('auth/detailUser', $data);
    }

    public function prosesEdit()
    {
        $id     = $this->input->post('id');
        $nama   = $this->input->post('nama');
        $akses  = $this->input->post('akses');
        $pt     = $this->input->post('pt');
        if ($akses == 1) {
            $aksess = 'Admin';
        } else {
            $aksess = 'User';
        }

        $data = [
            'nama_user' => $nama,
            'role'      => $akses,
            'status'    => $aksess,
            'pt'        => $pt
        ];

        ubah('user', $data, array('id' => $id));
    }

    public function detail()
    {
        $id = $this->input->post('id');

        $hasil = $this->db->query("SELECT nama_user, pt, status, id, role FROM user WHERE id = $id")->result();

        //perusahaan
        $db = $this->load->database('we', true);
        $pt = $db->query('SELECT id, name FROM ansena_department WHERE income = 1 ')->result();
        $ptArr = array();
        foreach ($pt as $row) {
            $ptArr['p' . $row->id] = $row->name;
        }
        $db->close();

        $data = [
            'hasil'     => $hasil,
            'pt'        => $ptArr,
            'daftarPt'  => $pt
        ];

        $this->load->view('auth/editUser', $data);
    }

    public function resetPassword()
    {
        $data = [
            'title' => 'Reset password'
        ];

        $this->load->view('layout/header', $data);
        $this->load->view('auth/resetPassword', $data);
        $this->load->view('layout/footer');
    }

    public function prosesReset()
    {
        $passLama = md5($this->input->post('passLama'));
        $pass = md5($this->input->post('passBaru'));

        $nama = $_SESSION['user'];
        $cekAkun = $this->db->query("SELECT password FROM user WHERE nama_user = '$nama'")->row_array();
        if ($passLama == $cekAkun['password']) {
            //proses edit password
            $dataEdit = [
                'password'  => $pass
            ];

            edit('user', $dataEdit, array('nama_user' => $nama));
            echo 'oke';
        } else {
            echo 'password tidak sama';
        }
    }
}
