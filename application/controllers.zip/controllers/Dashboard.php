<?php
defined('BASEPATH') or exit('No direct script allowed');

class Dashboard extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
    }

    public function index()
    {
        if (isset($_SESSION['login'])) {
            if ($_SESSION['role'] < 3) {
                $data = [
                    'title' => 'Dashboard',
                ];

                $this->load->view('layout/header', $data);
                $this->load->view('home/dashboard');
                $this->load->view('layout/footer');
            } else {
                $data = [
                    'title'     => 'Data visitor',
                    'visit'     => ambilData('visit')->result(),
                    'jumlah'    => ambilData('visit')->num_rows(),
                    'pt'        => ambilDataDb('we', 'ansena_department')->result(),
                    'marketing' => ambilDataEmpat('ac_payroll_item')->result(),
                    'brand'     => ambilDataDb('we', 'ansena_franchise_list')->result(),
                    'department'    => ambilDataDbWhere('we', 'ansena_department')->result(),
                    'alasan'        => ambilWhere(array('role'  => 1), 'alasan')->result(),
                    'jAlasan'       => ambilData('alasan')->num_rows()
                ];

                $this->load->view('layout/header', $data);
                $this->load->view('visitor/visitor', $data);
                $this->load->view('layout/footer');
            }
        } else {
            redirect('dashboard/redirect');
        }
    }

    public function redirect()
    {
        $this->load->view('errors/error');
    }

    public function ambilDataUtama()
    {
        $no = $this->input->post('no');
        $hasil = $this->db->query('SELECT hp, nama FROM visit WHERE hp = ' . $no)->result();
        echo json_encode($hasil);
    }

    public function find_data()
    {
        $no         = $this->input->post('no'); //ambil postingan (key)
        $id         = $this->input->post('id');
        $db3        = $this->input->post('db3');
        $kolom      = $this->input->post('kolom');
        $kolom2     = $this->input->post('kolom2');
        $table      = $this->input->post('table');
        $kolom3     = $this->input->post('kolom3');
        $table2     = $this->input->post('table2');

        //alasan
        $alasan = $this->db->query('SELECT * FROM alasan')->result();
        $alasanArray = array();
        foreach ($alasan as $row) :
            $key = 'id' . $row->id;
            $alasanArray[$key] = $row->alasan;
        endforeach;

        //perusahaan dan marketing, db brand
        $db2 = $this->load->database('we', true);

        $perusahaan = $db2->query('SELECT name, id, db FROM ansena_department WHERE income = 1')->result(); //list semua data di ansena department
        $marketing  = $db2->query('SELECT id, name FROM ac_payroll_item WHERE is_active = 1')->result();

        $perusahaanArray = array();
        $arrayBrand = array();

        foreach ($perusahaan as $row) {
            $id_pt  = $row->id;
            $perusahaanArray['p' . $row->id] = $row->name;
            $db = $row->db; //semua db
            $cek1 = $this->load->database($db, true);
            $brand = $cek1->query('SELECT id_franchise, nama_franchise FROM ansena_franchise_list')->result();
            foreach ($brand as $row) :
                $key = 'b' . $row->id_franchise;
                $arrayBrand['i' . $id_pt][$key] = $row->nama_franchise;
            endforeach;
        }

        $db2->close();

        $marketingArray = array();
        foreach ($marketing as $row) {
            $marketingArray['m' . $row->id] = $row->name;
        }

        //brand
        $idP = $_SESSION['pt'];
        $cekDb = $this->load->database('we', true);
        $hasilDb = $cekDb->query("SELECT db FROM ansena_department WHERE id = $idP ")->result();
        foreach ($hasilDb as $row) {
            $dbB = $row->db;
        }
        $cekDb->close();
        $dbBrand = $this->load->database($dbB, true);
        $brand = $dbBrand->query('SELECT id_franchise, nama_franchise FROM ansena_franchise_list')->result();
        $brandArray = array();
        foreach ($brand as $row) :
            $key = 'b' . $row->id_franchise;
            $brandArray[$key] = $row->nama_franchise;
        endforeach;
        $dbBrand->close();

        if (is_numeric($no)) {
            $hariIni = date('Y-m-d');

            $bulan = date('Y-m-d', strtotime('-1 month', strtotime($hariIni)));

            //load semua databse db 
            $loadDb = $this->load->database('we', true);
            $query = $loadDb->query('SELECT db FROM ansena_department WHERE income = 1')->result();
            foreach ($query as $d) {
                $cek3 = $d->db;
            }

            // $hasil = $this->db->query("SELECT nama, alasan, hp, brand, pt, id_visit, marketing, tanggal_join, tanggal_input, prospek FROM visit WHERE  tanggal_input >= '$bulan' AND tanggal_input <= '$hariIni' AND hp = $no AND kategori > 1 ORDER BY pt ASC");
            $this->db->select('nama, alasan, hp, brand, pt, id_visit, marketing, tanggal_join, tanggal_input, prospek');
            $this->db->where('tanggal_input >=', $bulan)
                ->where('tanggal_input <=', $hariIni)
                ->where('hp', $no)
                ->where('kategori >', 1)
                ->order_by('pt', 'ASC');
            $hasil = $this->db->get('visit');

            $limit = $this->db->query("SELECT nama, hp FROM visit WHERE hp = $no LIMIT 1")->result();

            $data = [
                'title'         => 'Detail',
                'hasil'         => $hasil->result(),
                'alasan'        => $alasanArray,
                'brand'         => $arrayBrand,
                'perusahaan'    => $perusahaanArray,
                'marketing'     => $marketingArray,
                'limit'         => $limit,
                'baris'         => $hasil->num_rows(),
                'id'            => $id,
                'hariIni'       => $hariIni,
                'bulan'         => $bulan
            ];
            $this->load->view('home/hasilNomor', $data);
        } else if ($id == 2) {
            $hariIni = date('Y-m-d');

            $bulan = date('Y-m-d', strtotime('-1 month', strtotime($hariIni)));

            // $hasil = $this->db->query("SELECT nama, alasan, hp, brand, pt, id_visit, marketing, tanggal_join, tanggal_input, prospek FROM visit WHERE nama = '$no' AND tanggal_input >= '$bulan' AND tanggal_input <= '$hariIni' AND kategori != 1 AND kategori != 0 ORDER BY tanggal_input ASC");
            $this->db->select('nama, alasan, hp, brand, pt, id_visit, marketing, tanggal_join, tanggal_input, prospek');
            $this->db->where('tanggal_input >=', $bulan)
                ->where('tanggal_input <=', $hariIni)
                ->where('nama', $no)
                ->where('kategori >', 1)
                ->order_by('tanggal_input', 'ASC');
            $hasil = $this->db->get('visit');

            $limit = $this->db->query("SELECT nama, hp FROM visit WHERE nama = '$no' LIMIT 1")->result();

            $data = [
                'title'         => 'Detail',
                'hasil'         => $hasil->result(),
                'alasan'        => $alasanArray,
                'brand'         => $arrayBrand,
                'perusahaan'    => $perusahaanArray,
                'marketing'     => $marketingArray,
                'limit'         => $limit,
                'baris'         => $hasil->num_rows(),
                'id'            => $id,
                'hariIni'       => $hariIni,
                'bulan'         => $bulan
            ];

            $this->load->view('home/hasilNomor', $data);
        } else if ($id >= 10 && $id < 34) {
            //cari brand

            $hariIni = date('Y-m-d');
            if ($id == 11) {
                $bulan = date('Y-m-d', strtotime('-1 month', strtotime($hariIni)));
                $prospek = 1;
            } else if ($id == 12) {
                $bulan = date('Y-m-d', strtotime('-2 month', strtotime($hariIni)));
                $prospek = 1;
            } else if ($id == 13) {
                $bulan = date('Y-m-d', strtotime('-3 month', strtotime($hariIni)));
                $prospek = 1;
            } else if ($id == 21) {
                $bulan = date('Y-m-d', strtotime('-1 month', strtotime($hariIni)));
                $prospek = 2;
            } else if ($id == 22) {
                $bulan = date('Y-m-d', strtotime('-2 month', strtotime($hariIni)));
                $prospek = 2;
            } else if ($id == 23) {
                $bulan = date('Y-m-d', strtotime('-3 month', strtotime($hariIni)));
                $prospek = 2;
            } else if ($id == 31) {
                $bulan = date('Y-m-d', strtotime('-1 month', strtotime($hariIni)));
                $prospek = 3;
            } else if ($id == 32) {
                $bulan = date('Y-m-d', strtotime('-2 month', strtotime($hariIni)));
                $prospek = 3;
            } else if ($id == 33) {
                $bulan = date('Y-m-d', strtotime('-3 month', strtotime($hariIni)));
                $prospek = 3;
            }

            $idBrandd = $this->brand($no);
            if ($idBrandd == 0) {
                echo '';
            } else {
                $idBrandd = $idBrandd['id_franchise'];
            }

            // $hasil = $this->db->query("SELECT nama, alasan, hp, brand, pt, id_visit, marketing, tanggal_join, tanggal_input, prospek FROM visit WHERE (tanggal_input >= '$bulan' AND tanggal_input <= '$hariIni' AND (brand = '$idBrandd' AND kategori > 1 AND prospek = $prospek AND tanggal_join = 'null')) ORDER BY tanggal_input ASC");
            $this->db->select('nama, alasan, hp, brand, pt, id_visit, marketing, tanggal_join, tanggal_input, prospek');
            $this->db->where('tanggal_input >=', $bulan)
                ->where('tanggal_input <=', $hariIni)
                ->where('brand', $idBrandd)
                ->where('kategori >', 1)
                ->where('prospek', $prospek)
                ->where('tanggal_join =', null)
                ->order_by('tanggal_input', 'ASC');
            $hasil = $this->db->get('visit');

            $limit = $this->db->query("SELECT nama, hp FROM visit WHERE brand = '$idBrandd' AND kategori != 1 AND kategori != 0 LIMIT 1")->result();

            $data = [
                'title'         => 'Detail',
                'hasil'         => $hasil->result(),
                'alasan'        => $alasanArray,
                'brand'         => $brandArray,
                'perusahaan'    => $perusahaanArray,
                'marketing'     => $marketingArray,
                'baris'         => $hasil->num_rows(),
                'id'            => $id,
                'hariIni'       => $hariIni,
                'bulan'         => $bulan
            ];

            $this->load->view('home/hasil', $data);
        } else if ($id >= 40 && $id <= 42) {
            $hariIni = date('Y-m-d');

            $cekBulan = $this->db->query('SELECT tanggal_input FROM visit ORDER BY tanggal_input asc LIMIT 1')->row_array();

            $idBrandd = $this->brand($no);
            if ($idBrandd != 'x') {
                if ($idBrandd == 0) {
                    echo '';
                } else {
                    $idBranddd = $idBrandd['id_franchise'];
                }

                $bulan = $cekBulan['tanggal_input'];

                if ($id == 40) {
                    $prospek = 1;
                } else if ($id == 41) {
                    $prospek = 2;
                } else if ($id == 42) {
                    $prospek = 3;
                }

                // $hasil = $this->db->query("SELECT nama, alasan, hp, brand, pt, id_visit, marketing, tanggal_join, tanggal_input, prospek FROM visit WHERE brand = '$idBrandd' AND kategori > 1 AND prospek = $prospek ORDER BY tanggal_input ASC");

                $this->db->select('nama, alasan, hp, brand, pt, id_visit, marketing, tanggal_join, tanggal_input, prospek');
                $this->db->where('brand =', $idBranddd)
                    ->where('kategori >', 1)
                    ->where('prospek', $prospek)
                    ->where('tanggal_join =', null)
                    ->order_by('tanggal_input', 'ASC');
                $hasil = $this->db->get('visit');

                $limit = $this->db->query("SELECT nama, hp FROM visit WHERE brand = '$idBranddd' AND kategori != 1 AND kategori != 0 LIMIT 1")->result();

                $data = [
                    'title'         => 'Detail',
                    'hasil'         => $hasil->result(),
                    'alasan'        => $alasanArray,
                    'brand'         => $brandArray,
                    'perusahaan'    => $perusahaanArray,
                    'marketing'     => $marketingArray,
                    'baris'         => $hasil->num_rows(),
                    'id'            => $id,
                    'hariIni'       => $hariIni,
                    'bulan'         => $bulan
                ];

                $this->load->view('home/hasil', $data);
            } else {
                echo '';
            }
        } else {
            echo '';
        }
    }

    public function brand($kunci)
    {
        $db = $this->load->database('we', true);
        $id = $_SESSION['pt'];
        $cekDb = $db->query('SELECT db FROM ansena_department WHERE id = ' . $id)->row_array();
        $dbB = $cekDb['db'];
        $db->close();

        //brand
        $dbBrand = $this->load->database($dbB, true);
        $check  = $dbBrand->query("SELECT id_franchise FROM ansena_franchise_list WHERE nama_franchise = '$kunci' ")->num_rows();
        $dbBrand->close();
        if ($check > 0) {
            $hasil = $dbBrand->query("SELECT id_franchise FROM ansena_franchise_list WHERE nama_franchise = '$kunci' ")->row_array();
            return $hasil;
        } else {
            return 'x';
        }
    }

    public function ambilPerusahaan()
    {
        $no = $this->input->post('no');

        $idPerusahaan = $this->db->query('SELECT pt FROM visit WHERE hp = ' . $no);
        echo json_encode($idPerusahaan->result());
    }

    public function autocomplete()
    {
        $data = $_GET['term'];
        $query = $this->db->query("SELECT hp FROM visit WHERE hp LIKE '$data%'")->result();
        $nomor = array();
        foreach ($query as $row) {
            $nomor[]   = $row->hp;
        }
        $arr = array_unique($nomor);
        echo json_encode($arr);
    }

    public function autocompleteNama()
    {
        $data = $_GET['term'];
        $query = $this->db->query("SELECT nama FROM visit WHERE nama LIKE '$data%'")->result();
        $nama = array();
        foreach ($query as $row) {
            $nama[]   = $row->nama;
        }
        $arr = array_unique($nama);
        echo json_encode($arr);
    }

    public function autocompleteBrand()
    {
        $data = $_GET['term'];

        $db = $this->load->database('we', true);

        $query = $db->query("SELECT nama_franchise FROM ansena_franchise_list WHERE nama_franchise LIKE '$data%'")->result();
        $nama = array();
        foreach ($query as $row) {
            $fr[]   = $row->nama_franchise;
        }
        echo json_encode($fr);
    }

    public function editData()
    {
        $id = $this->input->post('id');

        $query = $this->db->query('SELECT prospek FROM visit WHERE id_visit = ' . $id)->row_array();
        echo $query['prospek'];
    }

    public function prosesEdit()
    {
        $rating = $this->input->post('rating');
        $id = $this->input->post('id');

        $data = [
            'prospek'   => $rating
        ];

        edit('visit', $data, array('id_visit' => $id));
    }
}
